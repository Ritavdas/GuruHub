from django.db import models

class Registration(models.Model):
    name = models.CharField(max_length=100)
    username = models.CharField(max_length=100)
    email = models.CharField(max_length=100)
    password = models.CharField(max_length=100)
    conf_password = models.CharField(max_length=100)

    class Meta:
        db_table = "Reg"