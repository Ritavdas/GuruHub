from django.apps import AppConfig


class GuruhubConfig(AppConfig):
    name = 'guruhub'
